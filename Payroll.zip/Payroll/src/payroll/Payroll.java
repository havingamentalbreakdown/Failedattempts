package payroll;

import java.sql.*;


public class Payroll {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args){
        String user="root";
        String pass="";
        String url="jdbc:mysql://localhost:3306/test?characterEncoding=UTF-8";
        Connection conn=null;
        Statement stmn=null;
        Statement stmn1=null;
        String create_table="CREATE TABLE Employee.payroll ("
                            +"UID INT NOT NULL,"
                            +"NAME VARCHAR(45)NOT NULL,"
                            +"DOB DATE NOT NULL,"
                            +"PRIMARY KEY (UID))";
        
        try{
            Class.forName("com.mysql.cj.jdbc.Driver");
            System.out.println("Connecting to database...");
            conn= DriverManager.getConnection(url,user,pass);
            
            System.out.println("Creating database...");
            stmn=conn.createStatement();
            stmn1=conn.createStatement();
            
            String sql="CREATE DATABASE Employee";
            stmn.executeUpdate(sql);
            
            System.out.println("Database Employee created successfuly");
            stmn1.executeUpdate(create_table);
            
        }catch ( SQLException | ClassNotFoundException se){
            se.printStackTrace();
        }finally {
            try{
                if(stmn!=null){
                   stmn.close(); 
                }
            }catch (SQLException se2){
                
            }
            try{
               if(conn!=null){
                   conn.close();
               } 
            }catch (SQLException se){
                se.printStackTrace();
            }
        }
        
    System.out.println("Goodbye!");    
        
    }
    
}
        
       
        
       

        
        
        
        
            
     
    

